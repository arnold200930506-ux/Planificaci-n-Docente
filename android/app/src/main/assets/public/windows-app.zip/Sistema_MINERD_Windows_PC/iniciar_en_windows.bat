@echo off
title Sistema de Planificacion Docente MINERD - Escuela Dr. Jose Francisco Pena Gomez
echo =========================================================================
echo   SISTEMA DE PLANIFICACION DOCENTE MINERD
echo   Escuela Dr. Jose Francisco Pena Gomez (Codigo: 14668)
echo   Direccion: Licdo. Arnold Javier Sanchez
echo =========================================================================
echo.
echo [1/3] Verificando entorno Node.js / Electron...
call npm -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [AVISO] Node.js no fue detectado en su sistema.
    echo Abriendo la aplicacion directamente en su navegador web predeterminado...
    start "" "app/index.html"
    pause
    exit /b 0
)

echo [2/3] Instalando dependencias de escritorio (Electron)...
call npm install --silent

echo [3/3] Iniciando aplicacion de escritorio Windows...
call npm start
pause
